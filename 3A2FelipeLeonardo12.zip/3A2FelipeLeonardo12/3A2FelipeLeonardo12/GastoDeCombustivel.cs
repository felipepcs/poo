﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3A2FelipeLeonardo12
{
    class GastoDeCombustivel
    {
        public double DespesaMédia(double QuantidadeCombustivelMes, double ValorLitro)
        {
            return QuantidadeCombustivelMes * ValorLitro;
        }
        public double Revisao(double KmUltimaRevisao, double KmAtual)
        {
            return (KmUltimaRevisao + 10000) - KmAtual;
        }
        public double Automia(double QuantidadeDisponivel, double KmporLitro)
        {
            return (QuantidadeDisponivel - 10) * KmporLitro;
        }
    }
}
