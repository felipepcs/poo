﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3A2FelipeLeonardo12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            GastoDeCombustivel objAutomovel = new GastoDeCombustivel();

            double QuantidadeCombustivelMes, ValorLitro;

            if (!double.TryParse(txtQuantidadeAbastecida.Text, out QuantidadeCombustivelMes) || 
                !double.TryParse(txtValorLitro.Text, out ValorLitro))
            {
                MessageBox.Show("Insira valores válidos!");
            }
            else
            {
                txtResultadoMedia.Text = objAutomovel.DespesaMédia(QuantidadeCombustivelMes, ValorLitro).ToString("0.00");
            }

            double KmUltimaRevisao, KmAtual;

            if (!double.TryParse(txtUltimaRevisao.Text, out KmUltimaRevisao) ||
                !double.TryParse(txtQuilometragemAtual.Text, out KmAtual))
            {
                MessageBox.Show("Insira valores válidos!");
            }
            else
            {
                txtRevisao.Text = objAutomovel.Revisao(KmUltimaRevisao, KmAtual).ToString("0.00");
            }
            
            double QuantidadeDisponivel, KmporLitro;

            if (!double.TryParse(txtQuantidadeDisponivel.Text, out QuantidadeDisponivel) ||
                !double.TryParse(txtKmporLitro.Text, out KmporLitro))
            {
                MessageBox.Show("Insira valores válidos!");
            }
            else
            {
                txtAutonomia.Text = objAutomovel.Automia(QuantidadeDisponivel, KmporLitro).ToString("0.00");
            }
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtMarca.Clear();
            txtModelo.Clear();
            txtPlaca.Clear();
            txtValorAutomovel.Clear();
            txtQuilometragemAtual.Clear();
            txtUltimaRevisao.Clear();
            txtTipoCombustivel.Clear();
            txtQuantidadeAbastecida.Clear();
            txtQuantidadeDisponivel.Clear();
            txtValorLitro.Clear();
            txtKmporLitro.Clear();
            txtResultadoMedia.Clear();
            txtRevisao.Clear();
            txtAutonomia.Clear();
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}



