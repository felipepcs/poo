﻿namespace _3A2FelipeLeonardo12
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMarca = new System.Windows.Forms.Label();
            this.lblModelo = new System.Windows.Forms.Label();
            this.lblPlaca = new System.Windows.Forms.Label();
            this.lblValorAutomovel = new System.Windows.Forms.Label();
            this.lblTipoCombustivel = new System.Windows.Forms.Label();
            this.lblQuantidadeAbastecida = new System.Windows.Forms.Label();
            this.lblQuantidadeDisponivel = new System.Windows.Forms.Label();
            this.gpbAutomovel = new System.Windows.Forms.GroupBox();
            this.txtUltimaRevisao = new System.Windows.Forms.TextBox();
            this.lblUltimaRevisao = new System.Windows.Forms.Label();
            this.txtQuilometragemAtual = new System.Windows.Forms.TextBox();
            this.lblQuilometragemAtual = new System.Windows.Forms.Label();
            this.lblFins = new System.Windows.Forms.Label();
            this.txtValorAutomovel = new System.Windows.Forms.TextBox();
            this.txtPlaca = new System.Windows.Forms.TextBox();
            this.txtModelo = new System.Windows.Forms.TextBox();
            this.txtMarca = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtKmporLitro = new System.Windows.Forms.TextBox();
            this.lblKmporLitro = new System.Windows.Forms.Label();
            this.txtValorLitro = new System.Windows.Forms.TextBox();
            this.lblValorLitro = new System.Windows.Forms.Label();
            this.txtQuantidadeDisponivel = new System.Windows.Forms.TextBox();
            this.txtQuantidadeAbastecida = new System.Windows.Forms.TextBox();
            this.txtTipoCombustivel = new System.Windows.Forms.TextBox();
            this.lblDespesaMedia = new System.Windows.Forms.Label();
            this.lblRevisao = new System.Windows.Forms.Label();
            this.lblReserva = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.txtRevisao = new System.Windows.Forms.TextBox();
            this.txtResultadoMedia = new System.Windows.Forms.TextBox();
            this.txtAutonomia = new System.Windows.Forms.TextBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.gpbAutomovel.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblMarca
            // 
            this.lblMarca.AutoSize = true;
            this.lblMarca.BackColor = System.Drawing.SystemColors.Info;
            this.lblMarca.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMarca.Location = new System.Drawing.Point(6, 30);
            this.lblMarca.Name = "lblMarca";
            this.lblMarca.Size = new System.Drawing.Size(49, 16);
            this.lblMarca.TabIndex = 0;
            this.lblMarca.Text = "Marca:";
            // 
            // lblModelo
            // 
            this.lblModelo.AutoSize = true;
            this.lblModelo.BackColor = System.Drawing.SystemColors.Info;
            this.lblModelo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModelo.Location = new System.Drawing.Point(6, 61);
            this.lblModelo.Name = "lblModelo";
            this.lblModelo.Size = new System.Drawing.Size(57, 16);
            this.lblModelo.TabIndex = 1;
            this.lblModelo.Text = "Modelo:";
            // 
            // lblPlaca
            // 
            this.lblPlaca.AutoSize = true;
            this.lblPlaca.BackColor = System.Drawing.SystemColors.Info;
            this.lblPlaca.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlaca.Location = new System.Drawing.Point(6, 94);
            this.lblPlaca.Name = "lblPlaca";
            this.lblPlaca.Size = new System.Drawing.Size(46, 16);
            this.lblPlaca.TabIndex = 2;
            this.lblPlaca.Text = "Placa:";
            // 
            // lblValorAutomovel
            // 
            this.lblValorAutomovel.AutoSize = true;
            this.lblValorAutomovel.BackColor = System.Drawing.SystemColors.Info;
            this.lblValorAutomovel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorAutomovel.Location = new System.Drawing.Point(6, 129);
            this.lblValorAutomovel.Name = "lblValorAutomovel";
            this.lblValorAutomovel.Size = new System.Drawing.Size(43, 16);
            this.lblValorAutomovel.TabIndex = 3;
            this.lblValorAutomovel.Text = "Valor:";
            // 
            // lblTipoCombustivel
            // 
            this.lblTipoCombustivel.AutoSize = true;
            this.lblTipoCombustivel.BackColor = System.Drawing.SystemColors.Info;
            this.lblTipoCombustivel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoCombustivel.Location = new System.Drawing.Point(12, 27);
            this.lblTipoCombustivel.Name = "lblTipoCombustivel";
            this.lblTipoCombustivel.Size = new System.Drawing.Size(39, 16);
            this.lblTipoCombustivel.TabIndex = 4;
            this.lblTipoCombustivel.Text = "Tipo:";
            // 
            // lblQuantidadeAbastecida
            // 
            this.lblQuantidadeAbastecida.AutoSize = true;
            this.lblQuantidadeAbastecida.BackColor = System.Drawing.SystemColors.Info;
            this.lblQuantidadeAbastecida.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantidadeAbastecida.Location = new System.Drawing.Point(12, 61);
            this.lblQuantidadeAbastecida.Name = "lblQuantidadeAbastecida";
            this.lblQuantidadeAbastecida.Size = new System.Drawing.Size(187, 16);
            this.lblQuantidadeAbastecida.TabIndex = 5;
            this.lblQuantidadeAbastecida.Text = "Abastecimento mensal (litros):";
            // 
            // lblQuantidadeDisponivel
            // 
            this.lblQuantidadeDisponivel.AutoSize = true;
            this.lblQuantidadeDisponivel.BackColor = System.Drawing.SystemColors.Info;
            this.lblQuantidadeDisponivel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantidadeDisponivel.Location = new System.Drawing.Point(12, 94);
            this.lblQuantidadeDisponivel.Name = "lblQuantidadeDisponivel";
            this.lblQuantidadeDisponivel.Size = new System.Drawing.Size(185, 16);
            this.lblQuantidadeDisponivel.TabIndex = 6;
            this.lblQuantidadeDisponivel.Text = "Quantidade disponível (litros):";
            // 
            // gpbAutomovel
            // 
            this.gpbAutomovel.Controls.Add(this.txtUltimaRevisao);
            this.gpbAutomovel.Controls.Add(this.lblUltimaRevisao);
            this.gpbAutomovel.Controls.Add(this.txtQuilometragemAtual);
            this.gpbAutomovel.Controls.Add(this.lblQuilometragemAtual);
            this.gpbAutomovel.Controls.Add(this.lblFins);
            this.gpbAutomovel.Controls.Add(this.txtValorAutomovel);
            this.gpbAutomovel.Controls.Add(this.txtPlaca);
            this.gpbAutomovel.Controls.Add(this.txtModelo);
            this.gpbAutomovel.Controls.Add(this.txtMarca);
            this.gpbAutomovel.Controls.Add(this.lblMarca);
            this.gpbAutomovel.Controls.Add(this.lblModelo);
            this.gpbAutomovel.Controls.Add(this.lblPlaca);
            this.gpbAutomovel.Controls.Add(this.lblValorAutomovel);
            this.gpbAutomovel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbAutomovel.Location = new System.Drawing.Point(12, 12);
            this.gpbAutomovel.Name = "gpbAutomovel";
            this.gpbAutomovel.Size = new System.Drawing.Size(261, 231);
            this.gpbAutomovel.TabIndex = 7;
            this.gpbAutomovel.TabStop = false;
            this.gpbAutomovel.Text = "Dados do automóvel";
            // 
            // txtUltimaRevisao
            // 
            this.txtUltimaRevisao.Location = new System.Drawing.Point(144, 192);
            this.txtUltimaRevisao.Name = "txtUltimaRevisao";
            this.txtUltimaRevisao.Size = new System.Drawing.Size(100, 21);
            this.txtUltimaRevisao.TabIndex = 18;
            // 
            // lblUltimaRevisao
            // 
            this.lblUltimaRevisao.AutoSize = true;
            this.lblUltimaRevisao.BackColor = System.Drawing.SystemColors.Info;
            this.lblUltimaRevisao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUltimaRevisao.Location = new System.Drawing.Point(6, 195);
            this.lblUltimaRevisao.Name = "lblUltimaRevisao";
            this.lblUltimaRevisao.Size = new System.Drawing.Size(135, 16);
            this.lblUltimaRevisao.TabIndex = 17;
            this.lblUltimaRevisao.Text = "Km da última revisão:";
            // 
            // txtQuilometragemAtual
            // 
            this.txtQuilometragemAtual.Location = new System.Drawing.Point(144, 158);
            this.txtQuilometragemAtual.Name = "txtQuilometragemAtual";
            this.txtQuilometragemAtual.Size = new System.Drawing.Size(100, 21);
            this.txtQuilometragemAtual.TabIndex = 16;
            // 
            // lblQuilometragemAtual
            // 
            this.lblQuilometragemAtual.AutoSize = true;
            this.lblQuilometragemAtual.BackColor = System.Drawing.SystemColors.Info;
            this.lblQuilometragemAtual.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuilometragemAtual.Location = new System.Drawing.Point(6, 161);
            this.lblQuilometragemAtual.Name = "lblQuilometragemAtual";
            this.lblQuilometragemAtual.Size = new System.Drawing.Size(135, 16);
            this.lblQuilometragemAtual.TabIndex = 15;
            this.lblQuilometragemAtual.Text = "Quilometragem atual:";
            // 
            // lblFins
            // 
            this.lblFins.AutoSize = true;
            this.lblFins.BackColor = System.Drawing.SystemColors.Info;
            this.lblFins.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFins.Location = new System.Drawing.Point(187, 30);
            this.lblFins.Name = "lblFins";
            this.lblFins.Size = new System.Drawing.Size(0, 16);
            this.lblFins.TabIndex = 14;
            // 
            // txtValorAutomovel
            // 
            this.txtValorAutomovel.Location = new System.Drawing.Point(144, 123);
            this.txtValorAutomovel.Name = "txtValorAutomovel";
            this.txtValorAutomovel.Size = new System.Drawing.Size(100, 21);
            this.txtValorAutomovel.TabIndex = 10;
            // 
            // txtPlaca
            // 
            this.txtPlaca.Location = new System.Drawing.Point(144, 91);
            this.txtPlaca.Name = "txtPlaca";
            this.txtPlaca.Size = new System.Drawing.Size(100, 21);
            this.txtPlaca.TabIndex = 9;
            // 
            // txtModelo
            // 
            this.txtModelo.Location = new System.Drawing.Point(144, 58);
            this.txtModelo.Name = "txtModelo";
            this.txtModelo.Size = new System.Drawing.Size(100, 21);
            this.txtModelo.TabIndex = 8;
            // 
            // txtMarca
            // 
            this.txtMarca.Location = new System.Drawing.Point(144, 27);
            this.txtMarca.Name = "txtMarca";
            this.txtMarca.Size = new System.Drawing.Size(100, 21);
            this.txtMarca.TabIndex = 7;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtKmporLitro);
            this.groupBox1.Controls.Add(this.lblKmporLitro);
            this.groupBox1.Controls.Add(this.txtValorLitro);
            this.groupBox1.Controls.Add(this.lblValorLitro);
            this.groupBox1.Controls.Add(this.txtQuantidadeDisponivel);
            this.groupBox1.Controls.Add(this.txtQuantidadeAbastecida);
            this.groupBox1.Controls.Add(this.txtTipoCombustivel);
            this.groupBox1.Controls.Add(this.lblTipoCombustivel);
            this.groupBox1.Controls.Add(this.lblQuantidadeAbastecida);
            this.groupBox1.Controls.Add(this.lblQuantidadeDisponivel);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(279, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(354, 231);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dados referentes ao combustível";
            // 
            // txtKmporLitro
            // 
            this.txtKmporLitro.Location = new System.Drawing.Point(281, 158);
            this.txtKmporLitro.Name = "txtKmporLitro";
            this.txtKmporLitro.Size = new System.Drawing.Size(61, 21);
            this.txtKmporLitro.TabIndex = 17;
            // 
            // lblKmporLitro
            // 
            this.lblKmporLitro.AutoSize = true;
            this.lblKmporLitro.BackColor = System.Drawing.SystemColors.Info;
            this.lblKmporLitro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKmporLitro.Location = new System.Drawing.Point(12, 161);
            this.lblKmporLitro.Name = "lblKmporLitro";
            this.lblKmporLitro.Size = new System.Drawing.Size(65, 16);
            this.lblKmporLitro.TabIndex = 16;
            this.lblKmporLitro.Text = "Km / Litro:";
            // 
            // txtValorLitro
            // 
            this.txtValorLitro.Location = new System.Drawing.Point(281, 126);
            this.txtValorLitro.Name = "txtValorLitro";
            this.txtValorLitro.Size = new System.Drawing.Size(61, 21);
            this.txtValorLitro.TabIndex = 15;
            // 
            // lblValorLitro
            // 
            this.lblValorLitro.AutoSize = true;
            this.lblValorLitro.BackColor = System.Drawing.SystemColors.Info;
            this.lblValorLitro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorLitro.Location = new System.Drawing.Point(12, 126);
            this.lblValorLitro.Name = "lblValorLitro";
            this.lblValorLitro.Size = new System.Drawing.Size(78, 16);
            this.lblValorLitro.TabIndex = 14;
            this.lblValorLitro.Text = "Valor / Litro:";
            // 
            // txtQuantidadeDisponivel
            // 
            this.txtQuantidadeDisponivel.Location = new System.Drawing.Point(281, 91);
            this.txtQuantidadeDisponivel.Name = "txtQuantidadeDisponivel";
            this.txtQuantidadeDisponivel.Size = new System.Drawing.Size(61, 21);
            this.txtQuantidadeDisponivel.TabIndex = 11;
            // 
            // txtQuantidadeAbastecida
            // 
            this.txtQuantidadeAbastecida.Location = new System.Drawing.Point(281, 58);
            this.txtQuantidadeAbastecida.Name = "txtQuantidadeAbastecida";
            this.txtQuantidadeAbastecida.Size = new System.Drawing.Size(61, 21);
            this.txtQuantidadeAbastecida.TabIndex = 10;
            // 
            // txtTipoCombustivel
            // 
            this.txtTipoCombustivel.Location = new System.Drawing.Point(242, 24);
            this.txtTipoCombustivel.Name = "txtTipoCombustivel";
            this.txtTipoCombustivel.Size = new System.Drawing.Size(100, 21);
            this.txtTipoCombustivel.TabIndex = 9;
            // 
            // lblDespesaMedia
            // 
            this.lblDespesaMedia.AutoSize = true;
            this.lblDespesaMedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDespesaMedia.ForeColor = System.Drawing.Color.Red;
            this.lblDespesaMedia.Location = new System.Drawing.Point(18, 282);
            this.lblDespesaMedia.Name = "lblDespesaMedia";
            this.lblDespesaMedia.Size = new System.Drawing.Size(202, 16);
            this.lblDespesaMedia.TabIndex = 9;
            this.lblDespesaMedia.Text = "Despesa média de combustível:";
            // 
            // lblRevisao
            // 
            this.lblRevisao.AutoSize = true;
            this.lblRevisao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRevisao.ForeColor = System.Drawing.Color.Red;
            this.lblRevisao.Location = new System.Drawing.Point(12, 324);
            this.lblRevisao.Name = "lblRevisao";
            this.lblRevisao.Size = new System.Drawing.Size(295, 16);
            this.lblRevisao.TabIndex = 10;
            this.lblRevisao.Text = "Quilometragem restante para a proxima revisão:";
            // 
            // lblReserva
            // 
            this.lblReserva.AutoSize = true;
            this.lblReserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReserva.ForeColor = System.Drawing.Color.Red;
            this.lblReserva.Location = new System.Drawing.Point(12, 366);
            this.lblReserva.Name = "lblReserva";
            this.lblReserva.Size = new System.Drawing.Size(286, 16);
            this.lblReserva.TabIndex = 11;
            this.lblReserva.Text = "Distância a ser percorrida até atingir a reserva:";
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.LightGreen;
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(456, 262);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(144, 36);
            this.btnCalcular.TabIndex = 12;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(456, 304);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(144, 36);
            this.btnLimpar.TabIndex = 13;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // txtRevisao
            // 
            this.txtRevisao.Enabled = false;
            this.txtRevisao.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRevisao.Location = new System.Drawing.Point(318, 316);
            this.txtRevisao.Name = "txtRevisao";
            this.txtRevisao.Size = new System.Drawing.Size(90, 24);
            this.txtRevisao.TabIndex = 14;
            // 
            // txtResultadoMedia
            // 
            this.txtResultadoMedia.Enabled = false;
            this.txtResultadoMedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResultadoMedia.Location = new System.Drawing.Point(318, 274);
            this.txtResultadoMedia.Name = "txtResultadoMedia";
            this.txtResultadoMedia.Size = new System.Drawing.Size(90, 24);
            this.txtResultadoMedia.TabIndex = 15;
            // 
            // txtAutonomia
            // 
            this.txtAutonomia.Enabled = false;
            this.txtAutonomia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAutonomia.Location = new System.Drawing.Point(318, 358);
            this.txtAutonomia.Name = "txtAutonomia";
            this.txtAutonomia.Size = new System.Drawing.Size(90, 24);
            this.txtAutonomia.TabIndex = 16;
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.Salmon;
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Location = new System.Drawing.Point(456, 346);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(144, 36);
            this.btnSair.TabIndex = 18;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(651, 406);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.txtAutonomia);
            this.Controls.Add(this.txtResultadoMedia);
            this.Controls.Add(this.txtRevisao);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblReserva);
            this.Controls.Add(this.lblRevisao);
            this.Controls.Add(this.lblDespesaMedia);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gpbAutomovel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Gasto mensal do automóvel";
            this.gpbAutomovel.ResumeLayout(false);
            this.gpbAutomovel.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMarca;
        private System.Windows.Forms.Label lblModelo;
        private System.Windows.Forms.Label lblPlaca;
        private System.Windows.Forms.Label lblValorAutomovel;
        private System.Windows.Forms.Label lblTipoCombustivel;
        private System.Windows.Forms.Label lblQuantidadeAbastecida;
        private System.Windows.Forms.Label lblQuantidadeDisponivel;
        private System.Windows.Forms.GroupBox gpbAutomovel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtValorAutomovel;
        private System.Windows.Forms.TextBox txtPlaca;
        private System.Windows.Forms.TextBox txtModelo;
        private System.Windows.Forms.TextBox txtMarca;
        private System.Windows.Forms.TextBox txtQuantidadeDisponivel;
        private System.Windows.Forms.TextBox txtQuantidadeAbastecida;
        private System.Windows.Forms.TextBox txtTipoCombustivel;
        private System.Windows.Forms.Label lblDespesaMedia;
        private System.Windows.Forms.Label lblRevisao;
        private System.Windows.Forms.Label lblReserva;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.TextBox txtValorLitro;
        private System.Windows.Forms.Label lblValorLitro;
        private System.Windows.Forms.TextBox txtRevisao;
        private System.Windows.Forms.TextBox txtResultadoMedia;
        private System.Windows.Forms.TextBox txtAutonomia;
        private System.Windows.Forms.Label lblFins;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.TextBox txtQuilometragemAtual;
        private System.Windows.Forms.Label lblQuilometragemAtual;
        private System.Windows.Forms.TextBox txtUltimaRevisao;
        private System.Windows.Forms.Label lblUltimaRevisao;
        private System.Windows.Forms.TextBox txtKmporLitro;
        private System.Windows.Forms.Label lblKmporLitro;
    }
}

